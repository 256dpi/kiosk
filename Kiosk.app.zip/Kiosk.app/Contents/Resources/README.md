# kiosk

**a simple cocoa application for showing a website fullscreen**

## Installation

Download the executable or compile by yourself.

## Configuration

Create a configuration file ~/.kiosk with the URL as its content:

    http://www.example.com

